document.addEventListener('DOMContentLoaded', () => {
    // Elements
    // Elements
    // Elements
    const labelWidthInput = document.getElementById('labelWidth');

    const flowInput = document.getElementById('flow');
    const quantityInput = document.getElementById('quantity');
    const acrossInput = document.getElementById('across');
    const speedInput = document.getElementById('speed');

    const totalLengthEl = document.getElementById('totalLength');
    const totalAreaM2El = document.getElementById('totalAreaM2');
    const totalStrokesEl = document.getElementById('totalStrokes');
    const totalTimeEl = document.getElementById('totalTime');
    const resetBtn = document.getElementById('resetBtn');

    // Constants
    const MM_TO_M = 1000;
    const MM2_TO_M2 = 1000000;

    function calculate() {
        const width = parseFloat(labelWidthInput.value) || 0;
        const height = 0; // Removed input
        const flow = parseFloat(flowInput.value) || 0;
        const quantity = parseFloat(quantityInput.value) || 0;
        const across = parseFloat(acrossInput.value) || 1;
        const speed = parseFloat(speedInput.value) || 0;

        if (quantity === 0) {
            resetDisplay();
            return;
        }

        // 1. Technical Calcs
        const strokes = Math.ceil(quantity / across);

        // Formula: (Akış + Ara Boşluğu) * (Strokes / Across)
        // 'width' variable comes from 'Akış' input
        // 'flow' variable comes from 'Ara Boşluğu' input
        const repeatLengthMm = width + flow;
        const totalLengthMm = repeatLengthMm * (strokes / across);
        const totalLengthM = totalLengthMm / MM_TO_M;

        let timeMin = 0;
        if (speed > 0) {
            timeMin = totalLengthM / speed;
        }

        // Area Calculation (m²)
        // We use Total Length * Total Width (Effective width of material used)
        // OR simply Total Label Area? Usually material cost is based on raw material width.
        // But here we only have label dimensions. Let's assume Area = (Width + Gaps) * Length.
        // To be precise with inputs given: Total Area = (Label Width * Across) * Total Length. 
        // This approximates the utilized material area.
        const totalWidthMm = width * across;
        const totalAreaM2 = (totalWidthMm * totalLengthM) / 1000; // mm * m / 1000 = m²

        // Display Results
        totalLengthEl.innerHTML = `${formatNumber(totalLengthM)} <span class="unit-small">m</span>`;
        totalAreaM2El.innerHTML = `${formatNumber(totalAreaM2)} <span class="unit-small">m²</span>`;
        totalStrokesEl.innerHTML = `${formatNumber(strokes)}`;

        // Time display without decimal points (Math.ceil to be safe for production time, or Math.round)
        // User asked for "virgül olmadan" (without comma). Integer.
        // Using Math.ceil to ensure we account for any partial minute as a full minute of work usually,
        // or Math.round. Let's use Math.ceil as it is safer for "estimated time".
        // But simply "no comma" implies integer.
        // Let's use Math.round() for a standard approximation or toFixed(0).
        let timeDisplay = speed > 0 ? Math.ceil(timeMin) : '-';
        totalTimeEl.innerHTML = `${timeDisplay} <span class="unit-small">dk</span>`;
    }

    function formatNumber(num) {
        return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 2 }).format(num);
    }

    function resetDisplay() {
        totalLengthEl.innerHTML = `0 <span class="unit-small">m</span>`;
        totalAreaM2El.innerHTML = `0 <span class="unit-small">m²</span>`;
        totalStrokesEl.innerHTML = `0`;
        totalTimeEl.innerHTML = `0 <span class="unit-small">dk</span>`;
    }

    // Event Listeners
    const inputs = [
        labelWidthInput, flowInput, quantityInput,
        acrossInput, speedInput
    ];

    inputs.forEach(input => {
        input.addEventListener('input', calculate);
    });

    resetBtn.addEventListener('click', () => {
        labelWidthInput.value = '';

        flowInput.value = '3';
        quantityInput.value = '';
        acrossInput.value = '1';
        speedInput.value = '';
        resetDisplay();
        labelWidthInput.focus();
    });

    // Initial Focus
    labelWidthInput.focus();
});
